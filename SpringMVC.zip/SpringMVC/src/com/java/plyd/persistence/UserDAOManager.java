package com.java.plyd.persistence;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import org.springframework.stereotype.Repository;

import com.java.plyd.service.User;


@Repository("UserDAOManager")
public class UserDAOManager extends SqlMapClientDaoSupport implements IUserDAOManager  {

	
	public void Insert(User userinstance) {
		
		
			
			try {
				 getSqlMapClientTemplate().insert("User.insertUser", userinstance);
				
				
			} catch (Exception ex) {

			}
		
		
	}

	public void Delete(int uID) {
		
		
		
		try {
			 getSqlMapClientTemplate().delete("User.deleteUser", uID);
			
			
		} catch (Exception ex) {

		}
	
	
}
public void Update(User user) {
		
		
		
		try {
			 getSqlMapClientTemplate().update("User.updateUser", user);
			
			
		} catch (Exception ex) {

		}
	
	
}

	public List<User> selectAll() {
		
		
		List<User> userlist = null;
		try {
       			return getSqlMapClientTemplate().queryForList("User.selectAllUser");
       			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	
	
}

public User selectUser(int uID) {
		
		
		
		try {
       			return (User)getSqlMapClientTemplate().queryForObject("User.selectUser",uID);
       			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	
	
}
	@Override
	public User login(User userinstance) {
		// TODO Auto-generated method stub

		User user=new User();
		try {
			int isValid= (int) getSqlMapClientTemplate().queryForObject("User.isUser", userinstance);
			System.out.println(isValid+"valid");
			user.setUserName(userinstance.getUserName());
			if(isValid>=1){
				user.setValid(true);
			}
			else{
				user.setValid(false);
			}
		} catch (Exception ex) {

		}
		return user;
	
	
		
	}

}
