package com.java.plyd.persistence;

import java.util.ArrayList;
import java.util.List;

import com.java.plyd.service.User;


public interface IUserDAOManager {
	
	public  User login(User userinstance);
	public void Insert(User userinstance);
	public void Delete(int uID);
	public void Update(User userinstance);
	public List<User> selectAll();
	public User selectUser(int uID);
}
