package com.java.plyd.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.plyd.service.IUserService;
import com.java.plyd.service.SpringBeanFactory;
import com.java.plyd.service.User;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IUserService userService = (IUserService) SpringBeanFactory
				.getBean("UserService");

		String page = null;
		String param = request.getParameter("page");
		// String param="login";
		System.out.println(param + "Page");

		if (param.equals("loginform")) {
			page = "/presentation/login.jsp";
		}

		else if (param.equals("login")) {
			User user = new User();
			user.setUserName(request.getParameter("un"));
			user.setPassword(request.getParameter("pw"));

			User valid = userService.isValid(user);
		
			if (valid != null){
				 request.setAttribute("valid",valid);
				 page="/presentation/welcome.jsp";
			}
				 
			else
				 page="/presentation/invalid.jsp";

						
			
			

		}

		else if (param.equals("signup")) {

			page = "/presentation/signup.jsp";
		} else if (param.equals("add")) {
			User user = new User();

			user.setFirstName(request.getParameter("fn"));
			user.setLastName(request.getParameter("ln"));
			user.setUserName(request.getParameter("un"));
			user.setPassword(request.getParameter("pw"));

			userService.entry(user);
			// page="/presentation/search.jsp";
			List<User> userList = userService.selectAll();

			request.setAttribute("users", userList);
			page = "/presentation/search.jsp";

		} else if (param.equals("edit")) {
			User user = new User();
			user.setId(Integer.parseInt(request.getParameter("uid")));
			user.setFirstName(request.getParameter("fn"));
			user.setLastName(request.getParameter("ln"));
			user.setUserName(request.getParameter("un"));
			user.setPassword(request.getParameter("pw"));

			userService.edit(user);

			List<User> userList = userService.selectAll();

			request.setAttribute("users", userList);
			page = "/presentation/search.jsp";
		} else if (param.equals("remove")) {

			int uid = Integer.parseInt(request.getParameter("uid"));
			userService.remove(uid);
			List<User> userList = userService.selectAll();

			request.setAttribute("users", userList);
			//
			page = "/presentation/search.jsp";
		} else if (param.equals("search")) {

			List<User> userList = userService.selectAll();

			request.setAttribute("users", userList);

			page = "/presentation/search.jsp";
		} else if (param.equals("editform")) {
			int uid = Integer.parseInt(request.getParameter("uid"));
			User user = (User) userService.selectUser(uid);

			request.setAttribute("user", user);
			page = "/presentation/editform.jsp";
		}

		else {
			page = "/presentation/notfound.jsp";
		}

		getServletContext().getRequestDispatcher(page).forward(request,
				response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
