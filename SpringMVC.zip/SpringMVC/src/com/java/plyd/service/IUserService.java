package com.java.plyd.service;

import java.util.ArrayList;
import java.util.List;

public interface IUserService {
	public User isValid(User userinstance);
public void entry(User userinstance);
public void remove(int uID);
public void edit(User userinstance);
public List<User> selectAll();
public User selectUser(int uID);
}
