package com.java.plyd.service;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.java.plyd.persistence.IUserDAOManager;


@Service(value = "UserService")
public class UserService implements IUserService {

	@Resource(name = "UserDAOManager")
	private IUserDAOManager userDAOManager;

	public void entry(User userinstance) {

		// if(userinstance.getName()!=null ) {
		userDAOManager.Insert(userinstance);
		// }
		// else {
		// return 2;
		// }

	}

	@Override
	public void remove(int uID) {
		userDAOManager.Delete(uID);
	}

	@Override
	public void edit(User user) {
		userDAOManager.Update(user);
	}

	@Override
	public List<User> selectAll() {
		// TODO Auto-generated method stub
		return userDAOManager.selectAll();
	}

	@Override
	public User selectUser(int uID) {
		// TODO Auto-generated method stub
		return userDAOManager.selectUser(uID);
	}

	@Override
	public User isValid(User userinstance) {
		// TODO Auto-generated method stub
		User u = (User) userDAOManager.login(userinstance);
		return u;
	}

}
