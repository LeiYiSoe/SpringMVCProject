/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.0.45-community-nt : Database - mydb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mydb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mydb`;

/*Table structure for table `employee` */

CREATE TABLE `employee` (
  `id` int(10) NOT NULL,
  `first` varchar(100) default NULL,
  `last` varchar(100) default NULL,
  `age` int(5) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employee` */

insert  into `employee`(`id`,`first`,`last`,`age`) values (100,'Zara','Ali',18),(101,'Mahnaz','Ali',25),(102,'Zaid','Khan',30),(104,'Nuha','Ali',2),(104,'Paing','Paing',16),(1,'w','w',5);

/*Table structure for table `group` */

CREATE TABLE `group` (
  `id` int(11) default NULL,
  `name` varchar(50) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `group` */

/*Table structure for table `test_table` */

CREATE TABLE `test_table` (
  `country` varchar(2) default NULL,
  `id` int(11) default NULL,
  `a` int(11) default NULL,
  `b` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `test_table` */

insert  into `test_table`(`country`,`id`,`a`,`b`) values ('MM',1,1,2),('MM',1,1,1),('MM',2,1,1),('MM',2,9,9),('EE',1,100,100),('EE',2,1001,10001);

/*Table structure for table `user_table` */

CREATE TABLE `user_table` (
  `id` int(10) NOT NULL auto_increment,
  `first_name` varchar(100) default NULL,
  `last_name` varchar(100) default NULL,
  `user_name` varchar(100) default NULL,
  `password` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user_table` */

insert  into `user_table`(`id`,`first_name`,`last_name`,`user_name`,`password`) values (1,'Lei','Soe','lei','soe'),(2,'Htike','Htike','htike','htike');

/*Table structure for table `users` */

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `address` text,
  `password` varchar(255) default NULL,
  `remember_token` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`phone`,`address`,`password`,`remember_token`) values (1,'oo','oo@gmail.com','0986867868','-','$2y$10$kljYwYpGRomcb7z3ItayKuQtzE7nnAZ0oWUomU1KUns3jz5zM5MsW','GC6wWzdqzkYxSYC219ZF2sQspb6pNzxXQ72VME4UlWzpdcnXkeQQqxXea7jP'),(3,'leiyisoe','leiyisoe@gmail.com',NULL,NULL,'$2y$10$IbDhSRjUYRj1D9rIa2yv9uGTDP9eE0h0I8W02jvmz6vFWc0Yp7e8.','BitRsiZIHaGImgg8BHzdVTOQjZqH1B8PInNLzvI7dgsA44pK2aw8jZq1s1lz'),(5,'lys','leiyisoe@pearlyadana.com',NULL,NULL,'$2y$10$5XiQFxGzv/2oEOkK8ObbL..Y2wU7.D.hBb3Bx77N31AIzNvprgRqy',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
